function submitBillingForm() {
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const address = document.getElementById('address').value;
    const city = document.getElementById('city').value;
    const state = document.getElementById('state').value;
    const zip = document.getElementById('zip').value;
    const cardName = document.getElementById('card-name').value;
    const cardNumber = document.getElementById('card-number').value;
    const expiry = document.getElementById('expiry').value;
    const cvv = document.getElementById('cvv').value;

    // Simple validation for empty fields
    if (!name || !email || !address || !city || !state || !zip || !cardName || !cardNumber || !expiry || !cvv) {
        alert('Please fill in all fields.');
        return;
    }

    // Additional validation could go here (e.g., regex for email, card number format)

    // If validation passes, show confirmation message
    document.getElementById('billing-form').style.display = 'none';
    document.getElementById('confirmation').style.display = 'block';
}
let paymentsClient;

function onGooglePayLoaded() {
    paymentsClient = new google.payments.api.PaymentsClient({ environment: 'TEST' });
    
    const button = paymentsClient.createButton({ onClick: onGooglePaymentButtonClicked });
    document.getElementById('google-pay-button').appendChild(button);
    document.getElementById('google-pay-button').style.display = 'block';
}

function onGooglePaymentButtonClicked() {
    const paymentDataRequest = getGooglePaymentDataRequest();

    paymentsClient.loadPaymentData(paymentDataRequest)
        .then(paymentData => {
            processPayment(paymentData);
        })
        .catch(err => {
            console.error("Error loading Google Pay data", err);
        });
}

function getGooglePaymentDataRequest() {
    return {
        apiVersion: 2,
        apiVersionMinor: 0,
        allowedPaymentMethods: [{
            type: 'CARD',
            parameters: {
                allowedAuthMethods: ['PAN_ONLY', 'CRYPTOGRAM_3DS'],
                allowedCardNetworks: ['AMEX', 'DISCOVER', 'MASTERCARD', 'VISA']
            },
            tokenizationSpecification: {
                type: 'PAYMENT_GATEWAY',
                parameters: {
                    gateway: 'example', // Replace with your gateway name, e.g., 'stripe', 'braintree'
                    gatewayMerchantId: 'your-merchant-id' // Your merchant ID here
                }
            }
        }],
        merchantInfo: {
            merchantName: 'My Store',
            merchantId: 'your-merchant-id' // Replace with your actual Google Pay merchant ID
        },
        transactionInfo: {
            totalPriceStatus: 'FINAL',
            totalPrice: '1.00', // The amount you'd like to charge
            currencyCode: 'USD',
            countryCode: 'US'
        }
    };
}

function processPayment(paymentData) {
    // Process the payment with your backend (e.g., send it to your payment gateway)
    console.log("Payment received", paymentData);
}
// Get the modal
var modal = document.getElementById('promoModal');

// Get the button that opens the modal (you can add a button on your page or just trigger it automatically)
var closeBtn = document.getElementsByClassName('close-btn')[0];

// Show the modal after a few seconds
window.onload = function() {
    setTimeout(function() {
        modal.style.display = "block";
    }, 2000); // Show popup after 2 seconds
}

// Close the modal when the user clicks on the "x"
closeBtn.onclick = function() {
    modal.style.display = "none";
}

// Close the modal if the user clicks anywhere outside of the modal
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
var slideIndex = 0;
var slides = document.querySelector('.slides');

function showSlides() {
    slideIndex++;
    if (slideIndex >= slides.children.length) {
        slideIndex = 0; // Reset to the first slide
    }
    slides.style.transform = 'translateX(' + (-slideIndex * 100) + '%)';
}

setInterval(showSlides, 3000); // Change slide every 3 seconds
<!-- Home Section -->
<section id="home" class="page-section">
    <h1>Home</h1>
    <p>Welcome to our website!</p>
</section>

<!-- About Section -->
<section id="about" class="page-section" style="display:none;">
    <h1>About Us</h1>
    <p>Learn more about our company.</p>
</section>

<!-- Shop Section -->
<section id="shop" class="page-section" style="display:none;">
    <h1>Shop</h1>
    <p>Explore our products.</p>
</section>

<!-- Contact Section -->
<section id="contact" class="page-section" style="display:none;">
    <h1>Contact</h1>
    <p>Get in touch with us!</p>
</section>
<!-- Home Section -->
<section id="home" class="page-section">
    <h1>Home</h1>
    <p>Welcome to our website!</p>
</section>

<!-- About Section -->
<section id="about" class="page-section" style="display:none;">
    <h1>About Us</h1>
    <p>Learn more about our company.</p>
</section>

<!-- Shop Section -->
<section id="shop" class="page-section" style="display:none;">
    <h1>Shop</h1>
    <p>Explore our products.</p>
</section>

<!-- Contact Section -->
<section id="contact" class="page-section" style="display:none;">
    <h1>Contact</h1>
    <p>Get in touch with us!</p>
</section>
function showPage(pageId) {
    // Hide all sections
    const sections = document.querySelectorAll('.page-section');
    sections.forEach(section => {
        section.style.display = 'none';
    });

    // Show the selected page
    const page = document.getElementById(pageId);
    page.style.display = 'block';
}
/* Simple Navigation Styles */
nav ul {
    list-style: none;
    padding: 0;
    display: flex;
}

nav ul li {
    margin-right: 20px;
}

nav ul li a {
    text-decoration: none;
    color: #007BFF;
}


